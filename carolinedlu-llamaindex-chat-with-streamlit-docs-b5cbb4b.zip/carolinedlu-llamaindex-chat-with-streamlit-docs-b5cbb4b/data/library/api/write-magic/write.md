---
title: st.write
slug: /library/api-reference/write-magic/st.write
description: st.write writes arguments to the app.
---

<Autofunction function="streamlit.write" />

### Featured video

Learn what the [`st.write`](/library/api-reference/write-magic/st.write) and [magic](/library/api-reference/write-magic/magic) commands are and how to use them.

<YouTube videoId="wpDuY9I2fDg" />
