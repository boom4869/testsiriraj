---
title: st.column_config.NumberColumn
slug: /library/api-reference/data/st.column_config/st.column_config.numbercolumn
---

<Autofunction function="streamlit.column_config.NumberColumn" />
