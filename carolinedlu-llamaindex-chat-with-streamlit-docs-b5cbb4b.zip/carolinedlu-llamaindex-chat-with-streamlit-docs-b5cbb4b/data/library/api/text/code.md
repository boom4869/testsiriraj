---
title: st.code
slug: /library/api-reference/text/st.code
description: st.code displays a code block with optional syntax highlighting.
---

<Autofunction function="streamlit.code" />

<Image src="/images/api/st.code.png" clean />
