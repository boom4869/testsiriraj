---
title: st.file_uploader
slug: /library/api-reference/widgets/st.file_uploader
description: st.file_uploader displays a file uploader widget.
---

<Autofunction function="streamlit.file_uploader" />
