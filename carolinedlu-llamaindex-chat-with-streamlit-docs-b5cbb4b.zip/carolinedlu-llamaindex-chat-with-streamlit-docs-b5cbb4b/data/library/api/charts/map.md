---
title: st.map
slug: /library/api-reference/charts/st.map
description: st.map displays a map with points on it.
---

<Autofunction function="streamlit.map" />
