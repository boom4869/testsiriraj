---
title: st.exception
slug: /library/api-reference/status/st.exception
description: st.exception displays an exception.
---

<Autofunction function="streamlit.exception" />
