---
title: st.error
slug: /library/api-reference/status/st.error
description: st.error displays error message.
---

<Autofunction function="streamlit.error" />
