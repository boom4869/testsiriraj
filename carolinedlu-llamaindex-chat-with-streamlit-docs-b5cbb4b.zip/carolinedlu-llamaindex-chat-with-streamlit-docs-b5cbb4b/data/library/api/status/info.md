---
title: st.info
slug: /library/api-reference/status/st.info
description: st.info displays an informational message.
---

<Autofunction function="streamlit.info" />
